<?php
class Table3  {

   

    private $server = "localhost";
    private $username = "root";
    private $password;
    private $db = "oop_crud";
    private $conn;

    public function __construct(){
        try {
            
            $this->conn = new mysqli($this->server,$this->username,$this->password,$this->db);
        } catch (Exception $e) {
            echo "connection failed" . $e->getMessage();
        }

    }

    
		public function insert(){

			if (isset($_POST['submit'])) {
				if (isset($_POST['noteM1']) && isset($_POST['noteM2']) && isset($_POST['noteM3'])  && isset($_POST['noteM4'])  && isset($_POST['noteTotal'])  && isset($_POST['remarque'])) {
					if (!empty($_POST['noteM1']) && !empty($_POST['noteM2']) && !empty($_POST['noteM3'])  && !empty($_POST['noteM4'])  && !empty($_POST['noteTotal'])  && !empty($_POST['remarque'])) {
					
 						$noteM1 = $_POST['noteM1'];
 						$noteM2 = $_POST['noteM2'];
 						$noteM3 = $_POST['noteM3'];
 						$noteM4 = $_POST['noteM4'];
 						$noteTotal = $_POST['noteTotal'];
 						$remarque = $_POST['remarque'];


                        $query = "INSERT INTO table3 (noteM1,noteM2,noteM3,noteM4,noteTotal,remarque) VALUES ( '$noteM1','$noteM2','$noteM3','$noteM4' ,'$noteTotal','$remarque')";
						if ($sql = $this->conn->query($query)) {
							echo "<script>alert('records added successfully');</script>";
							echo "<script>window.location.href = 'note.php';</script>";
						}else{
							echo "<script>alert('failed');</script>";
							echo "<script>window.location.href = 'note.php';</script>";
						}

					}else{
						echo "<script>alert('empty');</script>";
						echo "<script>window.location.href = 'note.php';</script>";
					}

                    }
                }
            }
            public function fetch(){
                $data = null;
    
                $query = "SELECT * FROM table3";
                if ($sql = $this->conn->query($query)) {
                    while ($row = mysqli_fetch_assoc($sql)) {
                        $data[] = $row;
                    }
                }
                return $data;
            }

            public function delete($id){

                $query = "DELETE FROM table3 where id = '$id'";
                if ($sql = $this->conn->query($query)) {
                    return true;
                }else{
                    return false;
                }
            }

            
            public function fetch_single($id){

                $data = null;
    
                $query = "SELECT * FROM table3 WHERE id = '$id'";
                if ($sql = $this->conn->query($query)) {
                    while ($row = $sql->fetch_assoc()) {
                        $data = $row;
                    }
                }
                return $data;
            }

            public function edit($id){

                $data = null;
    
                $query = "SELECT * FROM table3 WHERE id = '$id'";
                if ($sql = $this->conn->query($query)) {
                    while($row = $sql->fetch_assoc()){
                        $data = $row;
                    }
                }
                return $data;
            }
    
            public function update($data){
    
                $query = "UPDATE table3 SET noteM1='$data[noteM1]', noteM2='$data[noteM2]', noteM3='$data[noteM3]' , noteM4='$data[noteM4]' , noteTotal='$data[noteTotal]' , remarque='$data[remarque]' WHERE id='$data[id] '";
    
                if ($sql = $this->conn->query($query)) {
                    return true;
                }else{
                    return false;
                }
            }
        



}

?>