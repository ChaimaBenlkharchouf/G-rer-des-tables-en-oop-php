<?php
class Table2  {

   

    private $server = "localhost";
    private $username = "root";
    private $password;
    private $db = "oop_crud";
    private $conn;

    public function __construct(){
        try {
            
            $this->conn = new mysqli($this->server,$this->username,$this->password,$this->db);
        } catch (Exception $e) {
            echo "connection failed" . $e->getMessage();
        }

    }

    
		public function insert(){

			if (isset($_POST['submit'])) {
				if (isset($_POST['module1']) && isset($_POST['module2']) && isset($_POST['module3'])  && isset($_POST['module4'])) {
					if (!empty($_POST['module1']) && !empty($_POST['module2']) && !empty($_POST['module3'])  && !empty($_POST['module4'])) {
					
 						$module1 = $_POST['module1'];
 						$module2 = $_POST['module2'];
 						$module3 = $_POST['module3'];
 						$module4 = $_POST['module4'];


                        $query = "INSERT INTO table2 (module1,module2,module3,module4) VALUES ( '$module1','$module2','$module3' ,'$module4')";
						if ($sql = $this->conn->query($query)) {
							echo "<script>alert('records added successfully');</script>";
							echo "<script>window.location.href = 'index.php';</script>";
						}else{
							echo "<script>alert('failed');</script>";
							echo "<script>window.location.href = 'index.php';</script>";
						}

					}else{
						echo "<script>alert('empty');</script>";
						echo "<script>window.location.href = 'index.php';</script>";
					}

                    }
                }
            }
            public function fetch(){
                $data = null;
    
                $query = "SELECT * FROM table2";
                if ($sql = $this->conn->query($query)) {
                    while ($row = mysqli_fetch_assoc($sql)) {
                        $data[] = $row;
                    }
                }
                return $data;
            }

            public function delete($id){

                $query = "DELETE FROM table2 where id = '$id'";
                if ($sql = $this->conn->query($query)) {
                    return true;
                }else{
                    return false;
                }
            }

            
            public function fetch_single($id){

                $data = null;
    
                $query = "SELECT * FROM table2 WHERE id = '$id'";
                if ($sql = $this->conn->query($query)) {
                    while ($row = $sql->fetch_assoc()) {
                        $data = $row;
                    }
                }
                return $data;
            }

            public function edit($id){

                $data = null;
    
                $query = "SELECT * FROM table2 WHERE id = '$id'";
                if ($sql = $this->conn->query($query)) {
                    while($row = $sql->fetch_assoc()){
                        $data = $row;
                    }
                }
                return $data;
            }
    
            public function update($data){
    
                $query = "UPDATE table2 SET module1='$data[module1]', module2='$data[module2]', module3='$data[module3]' , module4='$data[module4]' WHERE id='$data[id] '";
    
                if ($sql = $this->conn->query($query)) {
                    return true;
                }else{
                    return false;
                }
            }
        



}

?>