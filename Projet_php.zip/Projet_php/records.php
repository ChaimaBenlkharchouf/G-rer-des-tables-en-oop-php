<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title> Tableau d'affichage  </title>
    <style>

body{
  background-color: #F5F5D1;
}
th {
  background-color: #04AA6D;
  color: white;
}

    </style>
  </head>
  <body>
    <br><br><br><br><br>
    <div class="container">
      <div class="row">
        <div class="col-md-12 mt-5">
          <h1 class="text-center">Tableau d'affichage  </h1>
          <hr style="height: 1px;color: black;background-color: black;">
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nom complet</th>
                <th>Email</th>
                <th>N°Téléphone</th>
                <th>Addresse</th>
                <th>Filiére</th>
                <th>type du lp</th>
                <th>Date d'inscription </th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php

                include 'gereTable.php';
                include 'Table1.php';
                $model = new gereTable();
                $rows = $model->fetch();
                $model2 = new Table1();
                $rows1 = $model2->fetch();

                $i = 1;
                if(!empty($rows)  && !empty($rows1)){
                  foreach($rows as $row)
               
              ?>
              <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['mobile']; ?></td>
                <td><?php echo $row['address']; ?></td>
<?php         foreach($rows1 as $row2) ?>
                <td><?php echo $row2['filiere']; ?></td>
                <td><?php echo $row2['typeLP']; ?></td>
                <td><?php echo $row2['datee']; ?></td>
        

   

                <td>
                  <a href="read.php?id= <?php echo $row['id']  ; echo " ". $row2['id'];?>" class="badge badge-info">Voir</a>
                  <a href="delete.php?id=<?php echo $row['id']  ; echo " ". $row2['id'];?>" class="badge badge-danger">Supprimer</a>
                  <a href="edit.php?id=<?php echo $row['id']  ; echo " ". $row2['id'];?>" class="badge badge-success">Modufier</a>
                  <a href="module.php?id=<?php echo $row['id']  ; echo " ". $row2['id'];?>" class="badge badge-info">Module</a>
                  <a href="note.php?id=<?php echo $row['id']  ; echo " ". $row2['id'];?>" class="badge badge-success">Gestion de notes</a>

                </td>
              </tr>
<?php
                  


                  
                
}

              else{
                echo "no data";
            }

              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>