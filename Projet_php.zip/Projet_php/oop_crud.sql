-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 01 mars 2022 à 04:57
-- Version du serveur : 10.4.22-MariaDB
-- Version de PHP : 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `oop_crud`
--

-- --------------------------------------------------------

--
-- Structure de la table `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `records`
--

INSERT INTO `records` (`id`, `name`, `email`, `mobile`, `address`) VALUES
(1, 'HIBA', 'c@gmail.com', 3456, 'vv'),
(2, 'BENLKHARCHOUF', 'chaima1212@gmail.com', 0, 'El jadida'),
(3, 'HIBA', 'c@gmail.com', 3456, 'FGH'),
(4, 'c', 'HIBA17@gmail.com', 3456, 'BBBBB'),
(5, 'chaima', 'chaimaa@gmail.com', 64852, 'rien');

-- --------------------------------------------------------

--
-- Structure de la table `table1`
--

CREATE TABLE `table1` (
  `id` int(11) NOT NULL,
  `filiere` varchar(30) NOT NULL,
  `typeLP` varchar(30) NOT NULL,
  `datee` varchar(44) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `table1`
--

INSERT INTO `table1` (`id`, `filiere`, `typeLP`, `datee`) VALUES
(1, 'ldw', 'normal', '2022/20/21'),
(2, 'GH', 'val2', '2021-02-11'),
(3, 'GH', 'Licence temp a ménager', '2202-02-15'),
(4, 'ldw', 'Licence normale', '2022-02-12'),
(5, 'ldw', 'Licence temp a ménager', '2021-12-01');

-- --------------------------------------------------------

--
-- Structure de la table `table2`
--

CREATE TABLE `table2` (
  `id` int(11) NOT NULL,
  `module1` varchar(255) NOT NULL,
  `module2` varchar(255) NOT NULL,
  `module3` varchar(255) NOT NULL,
  `module4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `table2`
--

INSERT INTO `table2` (`id`, `module1`, `module2`, `module3`, `module4`) VALUES
(1, 'PHP', 'XML', 'JAVA', 'UML'),
(2, 'ENGLISH', 'Français', 'espagnol', 'arabe'),
(3, 'archi', 'C', 'C++', 'JS'),
(4, 'Reseaux', 'BDD', 'LUNIX', 'Algebre'),
(5, 'Analyse', 'algo', 'communication', 'gestion');

-- --------------------------------------------------------

--
-- Structure de la table `table3`
--

CREATE TABLE `table3` (
  `id` int(11) NOT NULL,
  `noteM1` float NOT NULL,
  `noteM2` float NOT NULL,
  `noteM3` float NOT NULL,
  `noteM4` float NOT NULL,
  `noteTotal` float NOT NULL,
  `remarque` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `table3`
--

INSERT INTO `table3` (`id`, `noteM1`, `noteM2`, `noteM3`, `noteM4`, `noteTotal`, `remarque`) VALUES
(1, 12, 13, 16, 14, 15, 'good'),
(2, 17, 19, 12, 10, 14, 'good'),
(3, 16, 18, 15, 14, 16, 'good%'),
(4, 13, 12, 15, 14, 13, 'ggggggg'),
(5, 15, 15, 16, 13, 14.75, 'Bien');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `table1`
--
ALTER TABLE `table1`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `table2`
--
ALTER TABLE `table2`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `table3`
--
ALTER TABLE `table3`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `table1`
--
ALTER TABLE `table1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `table2`
--
ALTER TABLE `table2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `table3`
--
ALTER TABLE `table3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
