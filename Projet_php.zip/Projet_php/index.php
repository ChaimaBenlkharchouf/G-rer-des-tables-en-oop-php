<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Projet php </title>
<style>

 * {
  margin: 0;
  padding: 0;
  background-color: #F5F5D1;
}
.main {
  height: 100vh;
  width: 100vw;
  position: relative;
}
.d1 {
  position: absolute;
  background-image: url(https://newevolutiondesigns.com/images/freebies/4k-wallpaper-3.jpg);
  background-size: 2700px 1500px;

  height: 30vh;
  width: 15vw;

  background-position: 0 50%;

  box-shadow: 0px 0px 25px rgba(0, 0, 0, 0.8);
  top: 50%;
  transform: translateY(-50%);
  z-index: 2;
  animation: dd1 10s 1, dd12 10s 1;
  animation-delay: 4s, 14s;
}
.d2 {
  position: absolute;
  background-image: url(https://newevolutiondesigns.com/images/freebies/4k-wallpaper-3.jpg);
  background-size: 2700px 1500px;

  height: 50vh;
  width: 25vw;

  background-position: -10vw 50%;
  left: 10vw;

  top: 50%;
  transform: translateY(-50%);
  z-index: 1;
  animation: dd2 10s 2;
  animation-delay: 4s;
}
.container {
  position: absolute;
  background-image: url(https://newevolutiondesigns.com/images/freebies/4k-wallpaper-3.jpg);
  background-size: 2700px 1500px;
  overflow: hidden;

  height: 150vh;
  width: 100vh;
  left: 25vw;
  box-shadow: 0px 0px 25px rgba(0, 0, 0, 0.8);
  background-position: -35vw 50%;

  top: 70%;
  transform: translateY(-50%);
  z-index: 3;
  animation: dd3 10s 2;
  animation-delay: 4s;
}
.d4 {
  position: absolute;
  overflow: hidden;
  background-image: url(https://newevolutiondesigns.com/images/freebies/4k-wallpaper-3.jpg);
  background-size: 2700px 1500px;

  height: 80vh;
  width: 25vw;
  left: 60vw;
  background-position: -70vw 50%;

  top: 50%;
  transform: translateY(-50%);
  z-index: 1;
  animation: dd4 10s 2;
  animation-delay: 4s;
}

@keyframes dd1 {
  0% {
  }
  50% {
    width: 95vw;
  }
}
@keyframes dd12 {
  0% {
  }
  50% {
    background-position: Calc(0vw - 40px) 50%;
  }
}
@keyframes dd2 {
  0% {
  }
  50% {
    background-position: Calc(-10vw - 40px) 50%;
  }
}
@keyframes dd3 {
  0% {
  }
  50% {
    background-position: Calc(-35vw - 40px) 50%;
  }
}
@keyframes dd4 {
  0% {
  }
  50% {
    background-position: Calc(-70vw - 40px) 50%;
  }
}

</style>


  </head>
  <body>
<div>
  <a href="records.php">Table d'affichage</a>   ||     <a href="index.php">Accueil</a>
</div>
  <div class="main">
    <div class="d1"></div>
    <div class="d2"></div>
    <div class="container"></div>
    <div class="d4"></div>


    <div class="container">
      <div class="row">
        <div class="col-md-12 mt-5">
          <h1 class="text-center">Formulaire d'inscription </h1>
          <hr style="height: 1px;color: black;background-color: black;">
        </div>
      </div>
      <div class="row">
        <div class="col-md-5 mx-auto">
          <?php

              include 'gereTable.php';
              $model = new gereTable();
              $insert = $model->insert();

              include 'Table1.php';
              $model1 = new Table1();
              $insert1 = $model1->insert();
              
              include 'Table2.php';
              $model2 = new Table2();
              $insert2 = $model2->insert();
          ?>
          <form action="" method="post">
            <div class="form-group">
              <label for="">Nom complet</label>
              <input type="text" name="name" class="form-control">
            </div>
            <div class="form-group">
              <label for="">Email</label>
              <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
              <label for="">N° Téléphonne</label>
              <input type="text" name="mobile" class="form-control">
            </div>
            <div class="form-group">
              <label for="">Addresse</label>
              <textarea name="address" id="" cols="" rows="3" class="form-control"></textarea>
            </div>

            <div class="form-group">
              <label for="">Filiére</label>
              <input name="filiere" type="text"/>
            </div>

            <div class="form-group">
              <label for="">Type de licence</label>
              <select name="typeLP">
               <option value="Licence normale"> Licence normale</option>
               <option value="Licence temp a ménager">Licence temp a ménager</option>
             </select>
            </div>

 <div class="form-group">
              <label for="">Date d'inscription </label>
              <input name="datee" type="date"/>
            </div>
         

            <div class="form-group">
              <label for="">Selectionner 4 module </label><br>
              PHP  <input name="module1" type="checkbox" value="PHP" /> 
              JAVA <input name="module2" type="checkbox" value="JAVA"/>
             xml <input name="module3" type="checkbox" value="XML"/>
              JEE<input name="module4" type="checkbox" value="JEE"/><br>
              ----------------------------------- <br>
              C<input name="module1" type="checkbox" value="C"/>
             C++ <input name="module2" type="checkbox" value="C++"/>
             UML <input name="module3" type="checkbox" value="UML"/>
             Merise <input name="module4" type="checkbox" value="Merise"/><br>
              ------------------------------------ <br>
             Communication <input name="module1" type="checkbox" value="comunication "/>
            Gestion  <input name="module2" type="checkbox" value="gestion"/>
             algebre <input name="module3" type="checkbox" value="algebre"/>
             analyse <input name="module4" type="checkbox" value="analyse"/>
            </div>



            <div class="form-group">
              <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </div>

  </body>
</html>