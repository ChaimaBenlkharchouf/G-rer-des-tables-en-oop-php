<?php 

	include 'gereTable.php';
	$model = new gereTable();
	$id = $_REQUEST['id'];
	$delete = $model->delete($id);

	include 'Table1.php';
	$model1 = new Table1();
	$id1 = $_REQUEST['id'];
	$delete1 = $model1->delete($id1);

	include 'Table2.php';
	$model2 = new Table2();
	$id2 = $_REQUEST['id'];
	$delete2 = $model2->delete($id2);

	if ($delete && $delete1 && $delete2) {
		echo "<script>alert('delete successfully');</script>";
		echo "<script>window.location.href = 'records.php';</script>";
	}





 ?>
